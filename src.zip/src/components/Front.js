import React, { Component } from 'react';


export class Front extends React.Component {
    render() {
        return (
            <div className="col-sm">
            One of Front columns
            </div>

        );
    }
}

export default Front;