import React, { Component } from 'react';


export class Back extends React.Component {
    render() {
        return (
            <div className="col-sm">
            One of Back columns
            </div>

        );
    }
}

export default Back;